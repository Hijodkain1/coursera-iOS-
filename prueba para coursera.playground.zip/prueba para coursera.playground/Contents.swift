//: Playground - noun: a place where people can play

import UIKit

var numbers = 0...100


for n in numbers {
   
   
    if n % 5 == 0 {
        print ("\(n) Bingo...")
    }
    if n >= 30 && n <= 40 {
        print ("\(n)\t viva Swif!")
    }
    if n % 2 == 0 {
        print ("\(n) Numero Par")
    }
    if n % 2 != 0 {
        print ("\(n) Numero Impar")
    }
    
}

